$(function () {

 
    $(".toggleSecond").click(function () {
        $("#toggle").slideToggle();
    })

    $(".fashion").click(function () {
        $(".ShopingDiv").slideToggle();
    })

    $(".fasearch").click(function () {
        $(".divPosition").slideToggle().css('cssText', $(".divPosition").attr('style') + 'display: ' + ("flex") + '!IMPORTANT;');
    })
    $(".fashionLink").click(function () {
        $(".slideNan").slideToggle();

    })
    $(".womenLink").click(function () {
        $(".women").slideToggle();

    })
    $(".menLink").click(function () {
        $(".men").slideToggle();

    })
    $(".kidsLink").click(function () {
        $(".kids").slideToggle();

    })
    $(".accessLink").click(function () {
        $(".access").slideToggle();
    })
    $(".pagess").click(function () {
        $(".pgClass").slideToggle();
    })

    $(".levels1").click(function () {
        $(".clasLevel").slideToggle();

    })
    $(".lvl2").click(function () {
        $(".claslvl1").slideToggle();

    })
    $(".lvl3").click(function () {
        $(".claslvl2").slideToggle();

    })
    $(".lvl4").click(function () {
        $(".claslvl3").slideToggle();

    })


    $(".bars").click(function () {
        $(".fixedDIv").animate({ left: "0px" }, 600);
        $(".opacit").css("display", "block");
    })
    $(".fa-times").click(function () {
        $(".fixedDIv").animate({ left: "-236px" }, 600);
        $(".opacit").css("display", "none");
    })

    $(".fixedDIv ul li .firstA").addClass("activ");
    $(".fixedDIv ul li a").click(function () {
        if ($(".fixedDIv ul li a").hasClass("activ")) {
            $(".fixedDIv ul li a").removeClass("activ");
            $(this).addClass("activ");
        }
    })

    $(".pgss").click(function () {
        $(".pagUl").slideToggle();
    })

    $(".navOpen").click(function () {
        $(".last").slideToggle();
    })

    $(".navCategori").click(function () {
        $("#drMenu").slideToggle();
    })

    $("#sladeCard li a").first().addClass("activs");
    $("#sladeCard li a").click(function (e) {
        e.preventDefault();
        if ($("#sladeCard li a").hasClass("activs")) {
            $("#sladeCard li a").removeClass("activs");
            $(this).addClass("activs");
        }
    })

    $("#sladeCard ul li a").click(function () {
        switch ($(this).attr("data-id")) {
            case "1":
                $("#sladeCard .owl-dots .owl-dot span")[0].click();
                break;
            case "2":
                $("#sladeCard .owl-dots .owl-dot span")[1].click();
                break;
            case "3":
                $("#sladeCard .owl-dots .owl-dot span")[2].click();
                break;
            case "4":
                $("#sladeCard .owl-dots .owl-dot span")[3].click();
                break;

            default:
                break;
        }
    })

    $("#sladeCard ul li .aTag").click(function () {
        switch ($(this).attr("data-id")) {
            case "1":
                $("#sladeCard .owl-dots .owl-dot span")[0].click();
                break;
            case "2":
                $("#sladeCard .owl-dots .owl-dot span")[1].click();
                break;
            case "3":
                $("#sladeCard .owl-dots .owl-dot span")[2].click();
                break;
            case "4":
                $("#sladeCard .owl-dots .owl-dot span")[3].click();
                $(".blockDiv").addClass(".noneDiv");
                break;

            default:
                break;
        }
    })

    // OwlCaousel
    $('#sliderShow .owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        center: true,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 1
            }
        }

    })


    var owl = $('#sliderShow .owl-carousel');
    owl.owlCarousel();
    // Go to the next item
    $('.rig').click(function () {
        owl.trigger('next.owl.carousel', [1000]);
    })
    // Go to the previous item
    $('.lef').click(function () {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        owl.trigger('prev.owl.carousel', [1000]);
    })

    // OwlCaousel

    // Second OwlCarousel
    $('#sladeCard .owl-carousel').owlCarousel({
        loop: true,
        mouseDrag: false,
        touchDrag: false,
        margin: 7,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 6
            }
        }

    })
    var owls = $('#sladeCard #owlSecond');
    owls.owlCarousel();
    // Go to the next item
    $('.rig').click(function () {
        owls.trigger('next.owl.carousel', [1000]);
    })
    // Go to the previous item
    $('.lef').click(function () {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        owls.trigger('prev.owl.carousel', [1000]);
    })


    // Second OwlCarousel
    // owlDotsUl
    $(".responsiveUl li a").click(function () {
        switch ($(this).attr("data-id")) {
            case "5":
                $("#sladeCard .owl-dots .owl-dot span")[0].click();
                break;
            case "6":
                $("#sladeCard .owl-dots .owl-dot span")[6].click();
                break;
            case "7":
                $("#sladeCard .owl-dots .owl-dot span")[12].click();
                break;
            case "8":
                $("#sladeCard .owl-dots .owl-dot span")[18].click();
                break;

            default:
                break;
        }
    })
    // owlDotsUl

    // owlPngImg
    $('#sladeCard .secondCol12 .divOwl #owlPngImg').owlCarousel({
        loop: true,
        items:7,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    });

    var owle = $('.secondCol12 .divOwl #owlPngImg');
    owle.owlCarousel();
    // Go to the next item
    $('.rigs').click(function () {
        owle.trigger('next.owl.carousel', [1000]);
    })
    // Go to the previous item
    $('.lefs').click(function () {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        owle.trigger('prev.owl.carousel', [1000]);
    })

    // owlPngImg



// Select Country//

var  selected = document.getElementById("selectedLang");


var language = ["English","Germany","Russian","Turkish"];
for (var i = 0; i < language.length; i++) {
    $(selected).append("<option>"+language[i]+"</option>");
    
     
}

// Select Country//
// select valute
var valute = document.getElementById("valute");
var val = ["Usd","Euro"];
for (var i = 0; i < val.length; i++) {
    $(valute).append("<option>"+val[i]+"</option>")
}

// select valute


})

