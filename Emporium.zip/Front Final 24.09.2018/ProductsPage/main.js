$(function () {

    var inputVal = document.querySelector(".inputVal").value;
    var inputVals = $(".inputVal")

    $(inputVals).css("width", inputVal + "px");

    // Navbar//

    $(".toggleSecond").click(function () {
        $("#toggle").slideToggle();
    })

    $(".fashion").click(function () {
        $(".ShopingDiv").slideToggle();
    })

    $(".fasearch").click(function () {
        $(".divPosition").slideToggle().css('cssText', $(".divPosition").attr('style') + 'display: ' + ("flex") + '!IMPORTANT;');
    })
    $(".fashionLink").click(function () {
        $(".slideNan").slideToggle();

    })
    $(".womenLink").click(function () {
        $(".women").slideToggle();

    })
    $(".menLink").click(function () {
        $(".men").slideToggle();

    })
    $(".kidsLink").click(function () {
        $(".kids").slideToggle();

    })
    $(".accessLink").click(function () {
        $(".access").slideToggle();
    })
    $(".pagess").click(function () {
        $(".pgClass").slideToggle();
    })

    $(".levels1").click(function () {
        $(".clasLevel").slideToggle();

    })
    $(".lvl2").click(function () {
        $(".claslvl1").slideToggle();

    })
    $(".lvl3").click(function () {
        $(".claslvl2").slideToggle();

    })
    $(".lvl4").click(function () {
        $(".claslvl3").slideToggle();

    })


    $(".bars").click(function () {
        $(".fixedDIv").animate({ left: "0px" }, 600);
        $(".opacit").css("display", "block");
    })
    $(".fa-times").click(function () {
        $(".fixedDIv").animate({ left: "-236px" }, 600);
        $(".opacit").css("display", "none");
    })

    $(".fixedDIv ul li .firstA").addClass("activ");
    $(".fixedDIv ul li a").click(function () {
        if ($(".fixedDIv ul li a").hasClass("activ")) {
            $(".fixedDIv ul li a").removeClass("activ");
            $(this).addClass("activ");
        }
    })

    $(".pgss").click(function () {
        $(".pagUl").slideToggle();
    })

    $(".navOpen").click(function () {
        $(".last").slideToggle();
    })

    $(".navCategori").click(function () {
        $("#drMenu").slideToggle();
    })

    $("#sladeCard li a").first().addClass("activs");
    $("#sladeCard li a").click(function (e) {
        e.preventDefault();
        if ($("#sladeCard li a").hasClass("activs")) {
            $("#sladeCard li a").removeClass("activs");
            $(this).addClass("activs");
        }
    })

    // Navbar//



    // Select Country//

    var selected = document.getElementById("selectedLang");


    var language = ["English", "Germany", "Russian", "Turkish"];
    for (var i = 0; i < language.length; i++) {
        $(selected).append("<option>" + language[i] + "</option>");


    }

    // Select Country//
    // select valute
    var valute = document.getElementById("valute");
    var val = ["Usd", "Euro"];
    for (var i = 0; i < val.length; i++) {
        $(valute).append("<option>" + val[i] + "</option>")
    }

    // select valute


    $("#appendUl1 li a").click(function () {
        $(".appendUl").fadeIn();
    });
    $(".appendUl").mouseleave(function () {
        $(".appendUl").fadeOut();
    });

    $(".divUl2 ul li .first").click(function () {
        $(".divUl2 .ulSecond").fadeIn();
    });

    $(".divUl2 .ulSecond").mouseleave(function () {
        $(this).fadeOut();
    });

    var boll = true;
    $(".divCategories h4").click(function(){
       
        if (boll) {
            $(".categoriUl").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            $(".headerDiv").css("height","1330px");
            boll = false;
            
        }else{
            $(".categoriUl").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            $(".headerDiv").css("height","auto")
            boll = true;
           
        }
    });

    $(".divPrice h4").click(function(){
        if (boll) {
            $(".rangeSlide").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".rangeSlide").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    });

    $(".colorDiv h4").click(function(){
        if (boll) {
            $(".colorUl").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".colorUl").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    });

    $(".size h4").click(function(){
        if (boll) {
            $(".sizeUl").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".sizeUl").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    });

    $(".contidion h4").click(function(){
        if (boll) {
            $(".contidionUl").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".contidionUl").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    });

    $(".brands h4").click(function(){
        if (boll) {
            $(".brandsUl").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".brandsUl").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    });

    $(".startingShop h4").click(function(){
        if (boll) {
            $(".divImg").slideDown();
            $(this).children().css("transform","rotate(0deg)");
            boll = false;
        }else{
            $(".divImg").slideUp();
            $(this).children().css("transform","rotate(180deg)");
            boll = true;
        }
    })

$(".blockDiv").click(function(){
    $(".hedColl3").css({"left":"0px"});
    $(".noneColl9").css("visibility","hidden");
})

$(".noneClose").click(function(){
    $(".hedColl3").css({"left":"-320px"});
    $(".noneColl9").css("visibility","visible");
})


})

